package com.abds.prototype1;

import org.springframework.web.bind.annotation.RestController;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import redis.clients.jedis.Jedis;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@RestController
public class MainController {

	@Autowired
	Jedis jedis;

	Map<String, String> planMap = new HashMap<String, String>();
	Map<String, String> planCostShareMap = new HashMap<String, String>();
	Map<String, String> linkedPlanServices = new HashMap<String, String>();
	Map<String, String> linkedService = new HashMap<String, String>();
	Map<String, String> planserviceCostShares = new HashMap<String, String>();

	@RequestMapping(value = "/plan", method = RequestMethod.POST)
	public @ResponseBody String savePlan(HttpServletRequest request, @RequestBody String object)
			throws JSONException, ProcessingException, IOException {

		if (!tokenValidation(request)) {
			return "Unauthorised";
		}

		JSONObject planJsonObj = new JSONObject(object);
		// Generate ETag
		String inputstream = planJsonObj.toString();
		InputStream is = new ByteArrayInputStream(inputstream.getBytes());
		String etag = generateETagHeaderValue(is);
		File schemaFile = new File("/Users/dchavan/Documents/json-schema.json");

		if (ValidationUtils.isJsonValid(schemaFile, object)) {
			Iterator<?> keys = planJsonObj.keys();
			String key = "";
			while (keys.hasNext()) {
				key = (String) keys.next();
				if (planJsonObj.get(key) instanceof JSONObject) {
					JSONObject planCostShareJsonObj = (JSONObject) planJsonObj.get(key);
					planCostShareMap = toMap(planCostShareJsonObj);
					save(planJsonObj.getString("_type") + "_" + planJsonObj.getString("_id") + "_" + key,
							planCostShareMap);
				} else if (planJsonObj.get(key) instanceof JSONArray) {
					JSONArray linkedPlanServicesJsonArray = (JSONArray) planJsonObj.get(key);
					for (int i = 0; i < linkedPlanServicesJsonArray.length(); i++) {
						JSONObject linkedServiceJsonObj = (JSONObject) linkedPlanServicesJsonArray.get(i);
						Iterator<?> linkedServiceKeys = linkedServiceJsonObj.keys();
						String linkedServiceKey = "";
						while (linkedServiceKeys.hasNext()) {
							linkedServiceKey = (String) linkedServiceKeys.next();
							if (linkedServiceJsonObj.get(linkedServiceKey) instanceof JSONObject) {
								JSONObject obj1 = (JSONObject) linkedServiceJsonObj.get(linkedServiceKey);
								linkedService = toMap(obj1);
								save(planJsonObj.getString("_type") + "_" + planJsonObj.getString("_id") + "_" + key
										+ "_" + linkedServiceJsonObj.getString("_id") + "_" + linkedServiceKey,
										linkedService);
								linkedService.clear();
							} else {
								linkedPlanServices.put(linkedServiceKey,
										String.valueOf(linkedServiceJsonObj.getString(linkedServiceKey)));
							}
						}
						save(linkedServiceJsonObj.getString("_type") + "_" + linkedServiceJsonObj.getString("_id"),
								linkedPlanServices);
						String sKey = planJsonObj.getString("_type") + "_" + planJsonObj.getString("_id") + "_" + key;
						jedis.sadd(sKey,
								linkedServiceJsonObj.getString("_type") + "_" + linkedServiceJsonObj.getString("_id"));
					}
				} else {
					planMap.put(key, String.valueOf(planJsonObj.get(key)));
				}
			}
			planMap.put("etag", etag);
			save(planJsonObj.getString("_type") + "_" + planJsonObj.getString("_id"), planMap);
		} else {
			return "Invalid JSON";
		}
		return "Plan saved successfully with id =" + planJsonObj.getString("_id");
	}

	public void save(String key, Map<String, String> planCostShareMap2) {
		jedis.hmset(key, planCostShareMap2);
	}

	@ResponseBody
	@RequestMapping(value = "/plan/{id}", method = RequestMethod.GET, produces = "application/json")
	public String getPlans(HttpServletRequest request, HttpServletResponse response, @PathVariable String id)
			throws JSONException, IOException {
		if (!tokenValidation(request)) {
			return "Unauthorised";
		}

		JSONObject object = new JSONObject();
		Map<String, String> plan = jedis.hgetAll("plan_" + id);
		if (!plan.isEmpty()) {
			String headerETag = request.getHeader("If-None-Match");
			String storedEtag = plan.get("etag");

			if (headerETag == null || storedEtag == null || !headerETag.equals(storedEtag)) {

				response.setHeader("Etag", storedEtag);
				Iterator it = plan.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry pairs = (Map.Entry) it.next();
					object.put((String) pairs.getKey(), pairs.getValue());
				}
				Map<String, String> planCostShare = jedis.hgetAll("plan_" + id + "_planCostShares");
				object.put("planCostShares", planCostShare);
				Set<String> setLinkedPlans = jedis.smembers("plan_" + id + "_linkedPlanServices");
				JSONArray linkedpricearray = new JSONArray();
				Iterator<String> iter = setLinkedPlans.iterator();
				while (iter.hasNext()) {
					String aaa = iter.next();
					Map<String, String> linkedPlanServices = jedis.hgetAll(aaa);
					JSONObject object1 = new JSONObject();
					Iterator iter1 = linkedPlanServices.entrySet().iterator();
					String idkey = "";
					while (iter1.hasNext()) {
						Map.Entry pairs = (Map.Entry) iter1.next();
						if (pairs.getKey().equals("_id")) {
							idkey = (String) pairs.getValue();

						}
						object1.put((String) pairs.getKey(), pairs.getValue());
					}
					String key_1 = "plan_" + id + "_linkedPlanServices_" + idkey + "_planserviceCostShares";
					String key_2 = "plan_" + id + "_linkedPlanServices_" + idkey + "_linkedService";
					Map<String, String> general1 = jedis.hgetAll(key_1);
					Map<String, String> general2 = jedis.hgetAll(key_2);
					object1.put("planserviceCostShares", general1);
					object1.put("linkedService", general2);
					linkedpricearray.put(object1);
				}
				object.put("linkedPlanServices", linkedpricearray);
				return object.toString();
			} else {
				response.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
			}
		} else {
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
			return object.toString();
		}
		return "";

	}

	@RequestMapping(value = "/plan/{id}", method = RequestMethod.DELETE)
	public @ResponseBody String deletePlan(HttpServletRequest request, HttpServletResponse response,
			@PathVariable String id) throws JSONException {
		if (!tokenValidation(request)) {
			return "Unauthorised";
		}
		Set<String> keys = jedis.keys("plan_" + id + "*");
		Set<String> linkedPlanServicesKeys = new HashSet<String>();
		for (String key : keys) {
			String o = "plan_" + id + "_linkedPlanServices";
			if (key.equals(o)) {
				linkedPlanServicesKeys = jedis.smembers(o);
				for (String k : linkedPlanServicesKeys) {
					linkedPlanServicesKeys.add(k);
				}
			}
		}
		if (!keys.isEmpty()) {
			jedis.del(linkedPlanServicesKeys.toArray(new String[linkedPlanServicesKeys.size()]));
			jedis.del(keys.toArray(new String[keys.size()]));
			return "Plan deleted successfully";
		}
		response.setStatus(HttpServletResponse.SC_NOT_FOUND);
		return "Plan does not exists";
	}

	@RequestMapping(value = "/plan/{id}", method = RequestMethod.PUT)
	public @ResponseBody String updatePlan(HttpServletRequest request, HttpServletResponse response,
			@PathVariable String id, @RequestBody String object)
			throws JSONException, ProcessingException, IOException {
		if (!tokenValidation(request)) {
			return "Unauthorised";
		}
		Map<String, String> plan = jedis.hgetAll("plan_" + id);
		if (!plan.isEmpty()) {
			String headerETag = request.getHeader("If-Match");
			String storedEtag = plan.get("etag");
			if (headerETag == null || storedEtag == null || headerETag.equals(storedEtag)) {
				String saveStatus = savePlan(request, object);
				if (saveStatus.equals("Invalid JSON")) {
					return saveStatus;
				} else {
					return "Plan updated successfully";
				}
			} else {
				response.setStatus(HttpServletResponse.SC_PRECONDITION_FAILED);
				return "";
			}
		} else {
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
			return "";
		}

	}

	public static Map<String, String> toMap(JSONObject object) throws JSONException {
		Map<String, String> map = new HashMap<String, String>();
		Iterator<String> keysItr = object.keys();
		while (keysItr.hasNext()) {
			String key = keysItr.next();
			Object value = object.get(key);
			if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			map.put(key, String.valueOf(value));
		}
		return map;
	}

	public String generateETagHeaderValue(InputStream inputStream) throws IOException {
		StringBuilder builder = new StringBuilder(37);
		DigestUtils.appendMd5DigestAsHex(inputStream, builder);
		return builder.toString();
	}

	public boolean tokenValidation(HttpServletRequest request) throws JSONException {
		final String secretKey = "ssshhhhhhhhhhh!!!!";
		String header = request.getHeader("Authorization");
		if (header.contains("Bearer") && header != null) {
			String token = header.split(" ")[1];
			String decryptedToken = AES.decrypt(token, secretKey);

			JSONObject js = new JSONObject(decryptedToken);
			Date cur_time = new Date();
			// Long t = (Long) js.get("expiry");
			Date token_Time = new Date(js.getString("expiry"));
			if (token_Time.compareTo(cur_time) > 0) {
				return true;
			}
		}
		return false;
	}

}