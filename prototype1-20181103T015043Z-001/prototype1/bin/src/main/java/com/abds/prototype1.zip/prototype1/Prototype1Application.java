package com.abds.prototype1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prototype1Application {

	public static void main(String[] args) {
		SpringApplication.run(Prototype1Application.class, args);
	}

}
